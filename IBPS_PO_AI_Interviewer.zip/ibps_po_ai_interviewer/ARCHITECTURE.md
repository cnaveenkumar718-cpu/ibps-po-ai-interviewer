# System architecture

```text
Candidate
   |
   v
Streamlit UI
   |
   +---- Candidate Profile
   |
   +---- Mock Interview
   |        |
   |        +--> AI Question Generator
   |        |
   |        +--> Text Answer
   |        |
   |        +--> Microphone -> Speech-to-Text
   |        |
   |        +--> Answer Evaluator
   |        |
   |        +--> Communication Signals
   |        |
   |        +--> Adaptive Difficulty
   |
   +---- Final Report
   |
   +---- SQLite History
```

## Scoring

Question-level score is produced by the evaluator:

- Knowledge
- Communication
- Relevance
- Professionalism

The final report additionally includes communication-signal proxy.

## Adaptive rule

- >= 80: increase difficulty
- < 55: decrease difficulty
- otherwise: keep current level

This is a training heuristic, not an official IBPS scoring formula.
