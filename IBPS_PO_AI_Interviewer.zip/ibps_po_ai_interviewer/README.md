# IBPS PO AI Interviewer

A Streamlit-based AI mock interviewer for IBPS PO interview practice.

## Features

- Candidate profile
- Personalized AI-generated questions
- Adaptive difficulty
- Typed or microphone answers
- Speech-to-text using an OpenAI transcription model
- Answer evaluation
- Communication/confidence proxy
- Final report
- SQLite interview history
- JSON report download
- Local/offline fallback for basic testing

## 10-phase mapping

1. Project design -> README + architecture
2. Streamlit UI -> app.py
3. Candidate profile -> Candidate Profile page
4. AI interviewer -> ai_engine.py
5. Voice input -> st.audio_input + transcription
6. Answer evaluation -> analyze_answer()
7. Confidence signals -> confidence.py
8. Adaptive interview -> difficulty adjustment
9. Final report -> generate_final_report()
10. Deployment -> deployment instructions below

## Run locally

### Windows PowerShell

```powershell
python -m venv .venv
.venv\Scripts\activate
pip install -r requirements.txt
$env:OPENAI_API_KEY="YOUR_KEY"
streamlit run app.py
```

### macOS/Linux

```bash
python3 -m venv .venv
source .venv/bin/activate
pip install -r requirements.txt
export OPENAI_API_KEY="YOUR_KEY"
streamlit run app.py
```

Open the local URL shown by Streamlit.

## Streamlit secrets

For deployment, create `.streamlit/secrets.toml` locally or add secrets in the hosting dashboard:

```toml
OPENAI_API_KEY = "YOUR_KEY"
OPENAI_MODEL = "gpt-6-luna"
OPENAI_TRANSCRIBE_MODEL = "gpt-4o-mini-transcribe"
```

## Important

Do not commit API keys to GitHub.

The confidence feature is a communication proxy, not a scientifically validated measurement of psychological confidence.

For a real interview-preparation product, review current IBPS notices and current-affairs material separately. The AI should not invent current events.

## Deployment outline

1. Put this project in a GitHub repository.
2. Test locally.
3. Connect the repository to Streamlit Community Cloud or another Python-capable host.
4. Set the API key as a secret.
5. Deploy `app.py`.
6. Test microphone permissions on the target phone/browser.

## Suggested next upgrades

- Add a curated current-affairs knowledge base.
- Add a PDF study-material uploader with retrieval.
- Add speech duration from audio metadata.
- Add browser-side webcam video analysis only with explicit consent.
- Add user accounts and encrypted storage for multi-user deployment.
- Add a question bank with reviewed banking questions.
