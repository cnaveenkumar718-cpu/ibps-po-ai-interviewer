import json
import os
import re
import sqlite3
import time
from datetime import datetime

import pandas as pd
import streamlit as st

from ai_engine import (
    analyze_answer,
    generate_question,
    generate_final_report,
    transcribe_audio,
)
from confidence import confidence_metrics
from db import init_db, save_session, list_sessions, load_session

st.set_page_config(page_title="IBPS PO AI Interviewer", page_icon="🏦", layout="wide")
init_db()

CATEGORIES = [
    "Self Introduction", "Education", "Hometown", "Family",
    "Why Banking?", "Why PO?", "Banking Awareness", "RBI",
    "Financial Awareness", "Economy", "Current Affairs",
    "Government Schemes", "Digital Banking", "Situational",
    "Ethics", "Customer Handling", "Leadership", "Stress / Cross-questioning"
]

def init_state():
    defaults = {
        "profile": {},
        "interview": [],
        "question_no": 0,
        "current_question": "",
        "difficulty": 2,
        "running": False,
        "finished": False,
        "mode": "AI Adaptive",
        "total_questions": 10,
    }
    for k, v in defaults.items():
        if k not in st.session_state:
            st.session_state[k] = v

init_state()

with st.sidebar:
    st.title("🏦 IBPS PO AI")
    st.caption("AI mock interview + communication analysis")
    page = st.radio(
        "Navigation",
        ["Home", "Candidate Profile", "Mock Interview", "Final Report", "History", "About"]
    )

def profile_complete():
    required = ["name", "education", "hometown", "state", "degree_subject", "hobbies"]
    return all(str(st.session_state.profile.get(x, "")).strip() for x in required)

def difficulty_label(n):
    return {1: "Easy", 2: "Moderate", 3: "Challenging", 4: "Stress / Cross-questioning"}.get(n, "Moderate")

def next_question():
    p = st.session_state.profile
    asked = [x["question"] for x in st.session_state.interview]
    q = generate_question(
        profile=p,
        asked_questions=asked,
        difficulty=difficulty_label(st.session_state.difficulty),
        mode=st.session_state.mode,
    )
    st.session_state.current_question = q

if page == "Home":
    st.title("🏦 IBPS PO AI Interviewer")
    st.write("A practice system designed to simulate an adaptive bank PO interview.")
    c1, c2, c3 = st.columns(3)
    c1.metric("Interview questions", st.session_state.total_questions)
    c2.metric("Adaptive levels", "4")
    c3.metric("Analysis", "AI + speech signals")

    st.subheader("10-phase build")
    phases = [
        ("1", "Project design", "Architecture, scoring model and interview flow"),
        ("2", "Streamlit UI", "Browser-based interface"),
        ("3", "Candidate profile", "Personalized question generation"),
        ("4", "AI interviewer", "Dynamic questions and follow-ups"),
        ("5", "Voice input", "Microphone recording and transcription"),
        ("6", "Answer evaluation", "Relevance, knowledge and communication"),
        ("7", "Confidence signals", "Pace, pauses and filler-word analysis"),
        ("8", "Adaptive interview", "Difficulty changes from performance"),
        ("9", "Final report", "Scores, strengths and improvement plan"),
        ("10", "Deployment", "Run locally or deploy to Streamlit Cloud"),
    ]
    for n, title, desc in phases:
        st.markdown(f"**Phase {n} — {title}**  \n{desc}")

    if not profile_complete():
        st.info("Start with Candidate Profile. You can then enter Mock Interview.")
    else:
        st.success(f"Profile ready for {st.session_state.profile.get('name')}.")

elif page == "Candidate Profile":
    st.title("👤 Candidate Profile")
    st.caption("These details personalize questions. Do not enter passwords, bank-account numbers or other sensitive information.")
    p = st.session_state.profile

    with st.form("profile_form"):
        name = st.text_input("Full name", p.get("name", ""))
        education = st.text_input("Highest qualification", p.get("education", ""))
        degree_subject = st.text_input("Degree / specialization", p.get("degree_subject", ""))
        college = st.text_input("College / university", p.get("college", ""))
        hometown = st.text_input("Hometown / city", p.get("hometown", ""))
        state = st.text_input("State", p.get("state", ""))
        hobbies = st.text_input("Hobbies", p.get("hobbies", ""))
        experience = st.text_area("Work / internship experience (if any)", p.get("experience", ""))
        achievements = st.text_area("Important achievements / certifications", p.get("achievements", ""))
        why_banking = st.text_area("Why banking? (optional draft)", p.get("why_banking", ""))
        why_po = st.text_area("Why PO? (optional draft)", p.get("why_po", ""))
        submit = st.form_submit_button("Save Profile", type="primary")
        if submit:
            st.session_state.profile = {
                "name": name, "education": education, "degree_subject": degree_subject,
                "college": college, "hometown": hometown, "state": state,
                "hobbies": hobbies, "experience": experience,
                "achievements": achievements, "why_banking": why_banking, "why_po": why_po
            }
            st.success("Profile saved.")

elif page == "Mock Interview":
    st.title("🎙️ Mock Interview")

    if not profile_complete():
        st.warning("Complete the Candidate Profile first.")
        st.stop()

    c1, c2, c3 = st.columns(3)
    st.session_state.total_questions = c1.number_input(
        "Number of questions", min_value=5, max_value=25,
        value=int(st.session_state.total_questions), step=1
    )
    st.session_state.mode = c2.selectbox(
        "Interview style", ["AI Adaptive", "Balanced", "Stress-heavy"],
        index=["AI Adaptive", "Balanced", "Stress-heavy"].index(st.session_state.mode)
    )
    if c3.button("Reset interview"):
        st.session_state.interview = []
        st.session_state.question_no = 0
        st.session_state.current_question = ""
        st.session_state.difficulty = 2
        st.session_state.running = False
        st.session_state.finished = False
        st.rerun()

    if not st.session_state.running and not st.session_state.finished:
        st.markdown("### Ready?")
        st.write("The interviewer will ask one question at a time. Record an answer or type one.")
        if st.button("▶ Start Interview", type="primary"):
            st.session_state.running = True
            st.session_state.question_no = 1
            st.session_state.difficulty = 2
            next_question()
            st.rerun()

    if st.session_state.running:
        st.progress(
            min((st.session_state.question_no - 1) / st.session_state.total_questions, 1.0),
            text=f"Question {st.session_state.question_no} of {st.session_state.total_questions}"
        )
        st.caption(f"Difficulty: {difficulty_label(st.session_state.difficulty)}")

        st.markdown("### Interviewer")
        st.info(st.session_state.current_question)

        answer = st.text_area("Typed answer (optional)", key=f"answer_{st.session_state.question_no}", height=160)
        audio = st.audio_input(
            "Or record your answer",
            sample_rate=16000,
            key=f"audio_{st.session_state.question_no}"
        )

        if audio:
            st.audio(audio)
            if st.button("Transcribe recording", key=f"transcribe_{st.session_state.question_no}"):
                with st.spinner("Transcribing..."):
                    try:
                        transcript = transcribe_audio(audio)
                        st.session_state[f"answer_{st.session_state.question_no}"] = transcript
                        st.success("Transcript inserted. Review it and click Submit Answer.")
                    except Exception as e:
                        st.error(f"Transcription failed: {e}")

        if st.button("Submit Answer", type="primary", key=f"submit_{st.session_state.question_no}"):
            final_answer = st.session_state.get(
                f"answer_{st.session_state.question_no}", ""
            ).strip()

            if not final_answer:
                st.error("Please type an answer or record/transcribe one.")
                st.stop()

            with st.spinner("Evaluating answer..."):
                evaluation = analyze_answer(
                    profile=st.session_state.profile,
                    question=st.session_state.current_question,
                    answer=final_answer,
                    difficulty=difficulty_label(st.session_state.difficulty),
                )

            signals = confidence_metrics(final_answer)
            record = {
                "question": st.session_state.current_question,
                "answer": final_answer,
                "evaluation": evaluation,
                "signals": signals,
                "difficulty": difficulty_label(st.session_state.difficulty),
                "timestamp": datetime.now().isoformat(timespec="seconds"),
            }
            st.session_state.interview.append(record)

            score = float(evaluation.get("overall_score", 60))
            if score >= 80:
                st.session_state.difficulty = min(4, st.session_state.difficulty + 1)
            elif score < 55:
                st.session_state.difficulty = max(1, st.session_state.difficulty - 1)

            if st.session_state.question_no >= st.session_state.total_questions:
                st.session_state.running = False
                st.session_state.finished = True
                report = generate_final_report(
                    profile=st.session_state.profile,
                    interview=st.session_state.interview,
                )
                st.session_state.final_report = report
                save_session(st.session_state.profile, st.session_state.interview, report)
                st.rerun()
            else:
                st.session_state.question_no += 1
                next_question()
                st.rerun()

elif page == "Final Report":
    st.title("📊 Final Interview Report")
    if not st.session_state.finished:
        st.info("Complete an interview first.")
        st.stop()

    report = st.session_state.get("final_report", {})
    if not report:
        st.warning("No report available.")
        st.stop()

    st.metric("Overall mock score", f"{report.get('overall_score', 0)}/100")
    cols = st.columns(5)
    for col, key in zip(
        cols,
        ["knowledge", "communication", "relevance", "professionalism", "confidence_signals"]
    ):
        col.metric(key.replace("_", " ").title(), f"{report.get(key, 0)}/100")

    st.subheader("Strengths")
    for x in report.get("strengths", []):
        st.success(x)

    st.subheader("Priority improvements")
    for x in report.get("weaknesses", []):
        st.warning(x)

    st.subheader("Action plan")
    for i, x in enumerate(report.get("action_plan", []), 1):
        st.write(f"{i}. {x}")

    st.subheader("Question-by-question")
    for i, item in enumerate(st.session_state.interview, 1):
        with st.expander(f"{i}. {item['question']}"):
            st.write("**Answer:**", item["answer"])
            ev = item["evaluation"]
            st.write(
                f"Knowledge: {ev.get('knowledge_score', 0)} | "
                f"Communication: {ev.get('communication_score', 0)} | "
                f"Relevance: {ev.get('relevance_score', 0)} | "
                f"Overall: {ev.get('overall_score', 0)}"
            )
            st.write("Feedback:", ev.get("feedback", ""))

    export = json.dumps(report, indent=2, ensure_ascii=False)
    st.download_button(
        "⬇ Download report JSON",
        export,
        file_name="ibps_po_mock_report.json",
        mime="application/json"
    )

elif page == "History":
    st.title("📚 Interview History")
    rows = list_sessions()
    if not rows:
        st.info("No completed interviews yet.")
    else:
        df = pd.DataFrame(rows)
        st.dataframe(df, use_container_width=True)
        selected = st.number_input(
            "Session ID to view", min_value=1,
            max_value=int(df["id"].max()), value=int(df["id"].max()), step=1
        )
        item = load_session(int(selected))
        if item:
            st.json(item["report"])

elif page == "About":
    st.title("ℹ️ About the project")
    st.markdown("""
### What this application measures

This is a **practice tool**, not a psychological or hiring assessment.

The confidence score is a proxy based on observable communication signals such as:
- answer length
- filler-word frequency
- hesitation markers
- sentence structure
- speech/transcript characteristics

It should not be interpreted as a clinical or scientifically validated measurement of confidence.

### Privacy

The default app stores completed interview text and scores in a local SQLite database.
If you deploy this online, review your hosting and API-provider privacy settings before using real candidate data.

### Suggested use

Do 3–5 mock interviews before the real interview:
1. Normal interview
2. Banking-heavy interview
3. Stress/cross-questioning interview
4. Profile-heavy interview
5. Final realistic simulation
""")
