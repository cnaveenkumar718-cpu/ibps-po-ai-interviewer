import re

FILLERS = {
    "um", "umm", "uh", "uhh", "actually", "basically",
    "like", "you know", "i mean"
}

def confidence_metrics(text: str):
    words = re.findall(r"\b[\w']+\b", text.lower())
    word_count = len(words)
    filler_count = sum(words.count(x) for x in FILLERS if " " not in x)
    for phrase in ["you know", "i mean"]:
        filler_count += text.lower().count(phrase)

    sentences = [x.strip() for x in re.split(r"[.!?]+", text) if x.strip()]
    avg_sentence_words = word_count / max(1, len(sentences))

    # This is deliberately a communication proxy, not a psychological confidence detector.
    score = 70
    if 45 <= word_count <= 180:
        score += 10
    elif word_count < 25:
        score -= 15
    elif word_count > 250:
        score -= 10

    score -= min(20, filler_count * 4)

    if 8 <= avg_sentence_words <= 28:
        score += 8
    elif avg_sentence_words > 40:
        score -= 6

    score = max(0, min(100, score))

    return {
        "word_count": word_count,
        "filler_count": filler_count,
        "sentence_count": len(sentences),
        "avg_sentence_words": round(avg_sentence_words, 1),
        "confidence_proxy": score,
        "note": "Proxy from answer text; not a validated psychological confidence measure."
    }
