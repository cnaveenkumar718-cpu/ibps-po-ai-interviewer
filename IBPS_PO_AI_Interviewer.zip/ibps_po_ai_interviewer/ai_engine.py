import json
import os
import re
from typing import Any

from openai import OpenAI

MODEL = os.getenv("OPENAI_MODEL", "gpt-6-luna")

def get_client():
    key = os.getenv("OPENAI_API_KEY")
    if not key:
        raise RuntimeError(
            "OPENAI_API_KEY is not set. Add it to your environment or Streamlit secrets."
        )
    return OpenAI(api_key=key)

def _json_from_text(text: str) -> dict:
    text = text.strip()
    if text.startswith("```"):
        text = re.sub(r"^```(?:json)?", "", text).strip()
        text = re.sub(r"```$", "", text).strip()
    try:
        return json.loads(text)
    except json.JSONDecodeError:
        m = re.search(r"\{.*\}", text, re.S)
        if m:
            return json.loads(m.group(0))
        raise

def call_json(instructions: str, payload: str) -> dict:
    client = get_client()
    response = client.responses.create(
        model=MODEL,
        instructions=instructions,
        input=payload,
    )
    return _json_from_text(response.output_text)

def generate_question(profile, asked_questions, difficulty, mode):
    instructions = """
You are an experienced Indian bank PO mock interviewer.
Generate exactly ONE interview question.
Use the candidate profile to personalize questions.
Do not reveal the scoring rubric.
Do not ask duplicate questions.
Ask professional, realistic questions suitable for a bank PO interview.
The question may be personal, educational, banking, RBI, economy, financial awareness,
current affairs, customer handling, ethics, leadership, or situational.
For current-affairs questions, do not invent facts. Prefer asking the candidate about
topics they can reasonably discuss rather than fabricating a supposedly current event.
Return JSON only: {"question":"..."}.
"""
    payload = json.dumps({
        "profile": profile,
        "already_asked": asked_questions[-20:],
        "difficulty": difficulty,
        "mode": mode,
    }, ensure_ascii=False)
    try:
        return call_json(instructions, payload)["question"]
    except Exception:
        fallback = [
            "Please introduce yourself and briefly explain why you want to join banking.",
            "Why do you want to become a Probationary Officer?",
            "How would you handle an angry customer whose transaction has failed?",
            "What qualities should a good bank officer have?",
            "How can your educational background help you in banking?",
        ]
        return fallback[len(asked_questions) % len(fallback)]

def analyze_answer(profile, question, answer, difficulty):
    instructions = """
Evaluate one candidate answer in an IBPS PO-style mock interview.
Do not claim to predict selection.
Use scores from 0 to 100.
Return JSON only with:
knowledge_score, communication_score, relevance_score, professionalism_score,
overall_score, strengths (array), weaknesses (array), feedback.
Judge the answer, not the person's worth. Do not infer sensitive traits.
Keep feedback practical and concise.
"""
    payload = json.dumps({
        "candidate_profile": profile,
        "question": question,
        "answer": answer,
        "difficulty": difficulty,
    }, ensure_ascii=False)
    try:
        return call_json(instructions, payload)
    except Exception:
        # Offline fallback: basic heuristic so the app still works without an API.
        words = answer.split()
        length_score = min(100, 45 + len(words))
        filler = len(re.findall(r"\b(umm+|uh+|actually|basically|like)\b", answer.lower()))
        comm = max(30, min(95, length_score - filler * 5))
        return {
            "knowledge_score": 60,
            "communication_score": int(comm),
            "relevance_score": 65,
            "professionalism_score": 70,
            "overall_score": int((60 + comm + 65 + 70) / 4),
            "strengths": ["Answer was attempted clearly."],
            "weaknesses": ["Enable the AI API for detailed answer-specific evaluation."],
            "feedback": "Use a clear structure: point, explanation, example, conclusion.",
        }

def generate_final_report(profile, interview):
    instructions = """
Create a final mock-interview report. This is training feedback, not a hiring prediction.
Return JSON only with:
overall_score, knowledge, communication, relevance, professionalism, confidence_signals,
strengths (array of 3-5), weaknesses (array of 3-5), action_plan (array of 5 practical items).
Use the question-level evaluations and communication signals.
"""
    payload = json.dumps({
        "profile": profile,
        "interview": interview,
    }, ensure_ascii=False)
    try:
        return call_json(instructions, payload)
    except Exception:
        if not interview:
            return {}
        def avg(path):
            vals = [float(x["evaluation"].get(path, 0)) for x in interview]
            return round(sum(vals) / len(vals)) if vals else 0
        conf = round(sum(x["signals"]["confidence_proxy"] for x in interview) / len(interview))
        knowledge = avg("knowledge_score")
        communication = avg("communication_score")
        relevance = avg("relevance_score")
        professionalism = avg("professionalism_score")
        overall = round((knowledge + communication + relevance + professionalism + conf) / 5)
        return {
            "overall_score": overall,
            "knowledge": knowledge,
            "communication": communication,
            "relevance": relevance,
            "professionalism": professionalism,
            "confidence_signals": conf,
            "strengths": ["Consistent participation", "Completed the full mock interview"],
            "weaknesses": ["Use AI mode for more specific feedback"],
            "action_plan": [
                "Practice a 60–90 second self-introduction.",
                "Revise banking and RBI fundamentals.",
                "Prepare profile-based questions from your education and hometown.",
                "Reduce filler words and long pauses.",
                "Do another mock interview under timed conditions.",
            ],
        }

def transcribe_audio(uploaded_audio):
    client = get_client()
    uploaded_audio.seek(0)
    result = client.audio.transcriptions.create(
        model=os.getenv("OPENAI_TRANSCRIBE_MODEL", "gpt-4o-mini-transcribe"),
        file=(uploaded_audio.name, uploaded_audio.getvalue(), uploaded_audio.type or "audio/wav"),
    )
    return result.text
