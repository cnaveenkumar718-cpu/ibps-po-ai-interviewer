# IBPS PO AI Interviewer — Project Report

## 1. Project title
AI-Based IBPS PO Mock Interview and Communication Analysis System

## 2. Problem statement
Candidates often practice interview questions using static lists. Static practice does not adapt to the candidate's profile or answers and gives limited feedback on communication.

## 3. Objective
Build an AI-assisted mock interview platform that:
- asks profile-specific questions;
- evaluates answers;
- adapts question difficulty;
- accepts voice answers;
- provides communication feedback;
- stores previous mock sessions.

## 4. Users
Primary user: IBPS PO interview candidate.

## 5. Modules
1. Candidate profile
2. AI question generation
3. Voice input
4. Speech transcription
5. Answer evaluation
6. Communication-signal analysis
7. Adaptive difficulty
8. Final report
9. Interview history
10. Deployment

## 6. Methodology
Profile -> question -> answer -> evaluation -> difficulty update -> next question -> final report.

## 7. Evaluation metrics
The application reports:
- Knowledge score
- Communication score
- Relevance score
- Professionalism score
- Confidence-signal proxy
- Overall practice score

These are application-defined training metrics and are not official IBPS marks.

## 8. Expected result
The candidate receives repeatable, personalized practice and a concrete improvement plan after every mock interview.

## 9. Limitations
- AI evaluation can be imperfect.
- Speech transcription can contain errors.
- Text-based confidence signals cannot establish psychological confidence.
- Current-affairs accuracy depends on the supplied knowledge source or prompt.
- This is not an official IBPS evaluation system.

## 10. Future scope
- Curated banking/current-affairs retrieval
- Reviewed question bank
- multilingual support
- real-time voice interviewer
- optional consent-based webcam analysis
- analytics across multiple sessions
