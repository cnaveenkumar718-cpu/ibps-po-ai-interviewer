# Deployment — simple path

## Option A: Local laptop

```bash
pip install -r requirements.txt
streamlit run app.py
```

## Option B: Streamlit Community Cloud

1. Create a GitHub repository.
2. Upload all project files.
3. Create a Streamlit app pointing to `app.py`.
4. In the app settings, add secrets:

```toml
OPENAI_API_KEY = "YOUR_KEY"
OPENAI_MODEL = "gpt-6-luna"
OPENAI_TRANSCRIBE_MODEL = "gpt-4o-mini-transcribe"
```

5. Deploy.
6. Test microphone access.

## Security checklist

- Never hard-code API keys.
- Never commit `.env`.
- Avoid storing sensitive personal information.
- If making the app public, add authentication before storing user histories.
- Consider disabling persistent storage for a simple family-only practice app.
