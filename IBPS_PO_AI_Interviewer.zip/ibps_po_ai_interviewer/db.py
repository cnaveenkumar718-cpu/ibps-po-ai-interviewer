import json
import sqlite3
from datetime import datetime
from pathlib import Path

DB_PATH = Path("interviews.db")

def init_db():
    conn = sqlite3.connect(DB_PATH)
    conn.execute("""
        CREATE TABLE IF NOT EXISTS sessions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            created_at TEXT NOT NULL,
            candidate_name TEXT,
            profile_json TEXT NOT NULL,
            interview_json TEXT NOT NULL,
            report_json TEXT NOT NULL
        )
    """)
    conn.commit()
    conn.close()

def save_session(profile, interview, report):
    conn = sqlite3.connect(DB_PATH)
    conn.execute(
        "INSERT INTO sessions(created_at,candidate_name,profile_json,interview_json,report_json) VALUES(?,?,?,?,?)",
        (
            datetime.now().isoformat(timespec="seconds"),
            profile.get("name", ""),
            json.dumps(profile, ensure_ascii=False),
            json.dumps(interview, ensure_ascii=False),
            json.dumps(report, ensure_ascii=False),
        ),
    )
    conn.commit()
    conn.close()

def list_sessions():
    conn = sqlite3.connect(DB_PATH)
    rows = conn.execute(
        "SELECT id, created_at, candidate_name, json_extract(report_json, '$.overall_score') AS score FROM sessions ORDER BY id DESC"
    ).fetchall()
    conn.close()
    return [
        {"id": r[0], "created_at": r[1], "candidate_name": r[2], "overall_score": r[3]}
        for r in rows
    ]

def load_session(session_id):
    conn = sqlite3.connect(DB_PATH)
    row = conn.execute(
        "SELECT profile_json, interview_json, report_json FROM sessions WHERE id=?",
        (session_id,)
    ).fetchone()
    conn.close()
    if not row:
        return None
    return {
        "profile": json.loads(row[0]),
        "interview": json.loads(row[1]),
        "report": json.loads(row[2]),
    }
